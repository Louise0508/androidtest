package com.cookandroid.dcu_image_viwer;

import android.os.Bundle;
import android.os.Environment;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_STORAGE_PERMISSION = 1;
    sajin picture;

    int curNum = 0;
    File[] imageFiles;
    String imageFname;
    private android.content.pm.PackageManager PackageManager;

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_STORAGE_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            } else {
                Toast.makeText(this, "Storage permission is required to access the SD card.", Toast.LENGTH_SHORT).show();
            }
        }
    }
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        picture = findViewById(R.id.sajin1);
        imageFiles = new File(Environment.getExternalStorageDirectory().getAbsolutePath()
                +"/Pictures").listFiles();
        imageFname = imageFiles[curNum].toString();
        picture.imagePath = imageFname;

        File[][] picID = {
                imageFiles, imageFiles, imageFiles, imageFiles, imageFiles,
                imageFiles, imageFiles, imageFiles, imageFiles, imageFiles,
                imageFiles, imageFiles, imageFiles, imageFiles, imageFiles
        };
    }
}

